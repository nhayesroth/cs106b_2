/* Instance variables */

   long id;        /* id linking this lock to the platform-specific data */
